package com.example.springboot.microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.example.springboot.microservices.controller.HelloWorldController;

@SpringBootApplication
//@ComponentScan(basePackageClasses = HelloWorldController.class)
public class SpringbootMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMicroservicesApplication.class, args);
	}

}
